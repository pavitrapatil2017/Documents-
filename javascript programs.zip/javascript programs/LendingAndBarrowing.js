const SHA256 = require('crypto-js/sha256');

// Define a class for a block in the blockchain
class Block {
    constructor(index, timestamp, data, previousHash = '') {
        this.index = index;
        this.timestamp = timestamp;
        this.data = data;
        this.previousHash = previousHash;
        this.hash = this.calculateHash();
        this.nonce = 0;
    }
// Method to calculate the hash of the block
calculateHash() {
    return SHA256(this.index + this.timestamp + JSON.stringify(this.data) + this.previousHash + this.nonce).toString();
}

// Method to mine the block (proof of work)
mineBlock(difficulty) {
    while (this.hash.substring(0, difficulty) !== Array(difficulty + 1).join("0")) {
        this.nonce++;
        this.hash = this.calculateHash();
    }
    console.log("Block mined: " + this.hash);
}
}

// Define a class for the blockchain
class Blockchain {
constructor() {
    this.chain = [this.createGenesisBlock()];
    this.difficulty = 4; // Difficulty level for mining
}

// Method to create the genesis block
createGenesisBlock() {
    return new Block(0, "01/01/2022", "Genesis Block", "0");
}

// Method to get the latest block in the blockchain
getLatestBlock() {
    return this.chain[this.chain.length - 1];
}

// Method to add a new block to the blockchain
addBlock(newBlock) {
    newBlock.previousHash = this.getLatestBlock().hash;
    newBlock.mineBlock(this.difficulty);
    this.chain.push(newBlock);
}

// Method to check if the blockchain is valid
isChainValid() {
    for (let i = 1; i < this.chain.length; i++) {
        const currentBlock = this.chain[i];
        const previousBlock = this.chain[i - 1];

        if (currentBlock.hash !== currentBlock.calculateHash()) {
            return false;
        }
        if (currentBlock.previousHash !== previousBlock.hash) {
            return false;
        }
    }
    return true;
}
}

// Create a new blockchain
let myBlockchain = new Blockchain();

// Add blocks to the blockchain
myBlockchain.addBlock(new Block(1, "10/01/2022", { amount: 4 }));
myBlockchain.addBlock(new Block(2, "12/01/2022", { amount: 10 }));

// Print the blockchain
console.log(JSON.stringify(myBlockchain, null, 4));

// Check if the blockchain is valid
console.log("Is blockchain valid? " + myBlockchain.isChainValid());
