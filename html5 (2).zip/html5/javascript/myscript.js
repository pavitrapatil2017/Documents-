var msg=document.getElementByTagName("p").value;
alert(msg);

function display()
{
var textboxvalue=document.getElementById("txt").value;
var passwordvalue=document.getElementById("pass").value;
if(textboxvalue=="edubridge" && passwordvalue=="12345" )
{
alert("success");
var msg=document.getElementByTagName("p");
msg.html
}else
alert("failed");


}