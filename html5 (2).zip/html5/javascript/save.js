alert("products on sale:\n"
+"1.leo mobile\n"+
"2.leo camera\n"
+"3.red shoes\n"
+"4.kp watch\n");
function display()
{
alert("hello function")
}