document.write('hello this is java script');
alert('hello');